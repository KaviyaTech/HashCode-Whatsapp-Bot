function Jsl_0x39e7(){const _0x4ab96a=['_Successfully\x20updated_','HEROKU_API_KEY','jid','1894707RGjAgV','client','push','5198105seUjPS','HEROKU_APP_NAME','main','Updates\x20bot','1550906TtoLlD','𝐒𝐓𝐀𝐑𝐓\x20𝐔𝐏𝐃𝐀𝐓𝐄','https://','_Started\x20update.._','addRemote','stream','1409784DzIDQQ','https://api:','_Bot\x20up\x20to\x20date_','../config','https://i.imgur.com/tZhLHEr.jpeg','fetch','531QVeXgF','FETCH_HEAD','heroku-client','@whiskeysockets/baileys','695495DaPoCA','reply','_Restarting_','log','𝐔𝐏𝐃𝐀𝐓𝐄\x20𝐂𝐇𝐄𝐂𝐊𝐄𝐑!','158392ocKRcW','35ZAnXMA','hard','sendMessage','owner','Heroku\x20information\x20wrong!','_Bot\x20up\x20to\x20date!_','update','exec','replace','heroku','upstream','get','message','../lib/','/apps/','1190888GJrbCU','..origin/','all','heroku\x20remote\x20ekli'];Jsl_0x39e7=function(){return _0x4ab96a;};return Jsl_0x39e7();}const Jsl_0x58eab9=Jsl_0x3678;(function(_0x159da1,_0x4d14a5){const _0x5a4665=Jsl_0x3678,_0x2cff43=_0x159da1();while(!![]){try{const _0x50f57e=-parseInt(_0x5a4665(0x1fb))/0x1+parseInt(_0x5a4665(0x21e))/0x2+-parseInt(_0x5a4665(0x217))/0x3+parseInt(_0x5a4665(0x210))/0x4+parseInt(_0x5a4665(0x21a))/0x5+parseInt(_0x5a4665(0x224))/0x6*(parseInt(_0x5a4665(0x201))/0x7)+parseInt(_0x5a4665(0x200))/0x8*(-parseInt(_0x5a4665(0x1f7))/0x9);if(_0x50f57e===_0x4d14a5)break;else _0x2cff43['push'](_0x2cff43['shift']());}catch(_0x1f9705){_0x2cff43['push'](_0x2cff43['shift']());}}}(Jsl_0x39e7,0xc175b));const simpleGit=require('simple-git'),git=simpleGit(),{Module}=require(Jsl_0x58eab9(0x20e)),{MessageType}=require(Jsl_0x58eab9(0x1fa)),Config=require(Jsl_0x58eab9(0x1f4)),exec=require('child_process')[Jsl_0x58eab9(0x208)],Heroku=require(Jsl_0x58eab9(0x1f9)),{PassThrough}=require(Jsl_0x58eab9(0x223)),heroku=new Heroku({'token':Config[Jsl_0x58eab9(0x215)]}),{jslbuffer}=require('abu-bot');function Jsl_0x3678(_0x3745cf,_0x433a43){const _0x39e791=Jsl_0x39e7();return Jsl_0x3678=function(_0x367834,_0x57437a){_0x367834=_0x367834-0x1f4;let _0x2546d8=_0x39e791[_0x367834];return _0x2546d8;},Jsl_0x3678(_0x3745cf,_0x433a43);}Module({'pattern':'jail','fromMe':!![],'desc':Jsl_0x58eab9(0x21d),'type':Jsl_0x58eab9(0x204)},async(_0x54141e,_0x4f34f8)=>{const _0x597718=Jsl_0x58eab9;await git[_0x597718(0x1f6)]();var _0x2dc5e0=await git[_0x597718(0x1fe)]([_0x597718(0x21c)+_0x597718(0x211)+_0x597718(0x21c)]),_0x299740='';if(_0x2dc5e0['total']===0x0)return _0x299740=_0x597718(0x206),await _0x54141e[_0x597718(0x1fc)](_0x299740);else{var _0x1230b5='_Pending\x20updates:_\x0a\x0a';for(var _0x1ca71c in _0x2dc5e0[_0x597718(0x212)]){_0x1230b5+='_'+(parseInt(_0x1ca71c)+0x1)+'\x20:\x20_'+_0x2dc5e0[_0x597718(0x212)][_0x1ca71c][_0x597718(0x20d)]+'_\x0a';}_0x299740=_0x1230b5;var _0x387cd0=[{'buttonId':'.fd','buttonText':{'displayText':_0x597718(0x21f)},'type':0x1}];}const _0x2daebd={'image':{'url':_0x597718(0x1f5)},'caption':_0x299740,'footer':_0x597718(0x1ff),'buttons':_0x387cd0,'headerType':0x1};return await _0x54141e[_0x597718(0x218)]['sendMessage'](_0x54141e[_0x597718(0x216)],_0x2daebd);}),Module({'pattern':'start update','type':'owner','fromMe':!![],'dontAddCommandList':!![],'desc':Jsl_0x58eab9(0x21d)},async(_0x197753,_0x31991b)=>{const _0x1faec1=Jsl_0x58eab9;await git[_0x1faec1(0x1f6)]();var _0x1edfa6=await git[_0x1faec1(0x1fe)]([_0x1faec1(0x21c)+'..origin/'+_0x1faec1(0x21c)]);if(_0x1edfa6['total']===0x0)return await _0x197753['client'][_0x1faec1(0x203)](_0x197753[_0x1faec1(0x216)],{'text':_0x1faec1(0x226)});else{await _0x197753['client']['sendMessage'](_0x197753[_0x1faec1(0x216)],{'text':_0x1faec1(0x221)});try{var _0x208975=await heroku[_0x1faec1(0x20c)](_0x1faec1(0x20f)+Config[_0x1faec1(0x21b)]);}catch{await _0x197753[_0x1faec1(0x218)]['sendMessage'](_0x197753[_0x1faec1(0x216)],{'text':_0x1faec1(0x205)}),await new Promise(_0x42a11b=>setTimeout(_0x42a11b,0x3e8));}git[_0x1faec1(0x1f6)](_0x1faec1(0x20b),_0x1faec1(0x21c)),git['reset'](_0x1faec1(0x202),[_0x1faec1(0x1f8)]);var _0x1317c6=_0x208975['git_url'][_0x1faec1(0x209)](_0x1faec1(0x220),_0x1faec1(0x225)+Config['HEROKU_API_KEY']+'@');try{await git[_0x1faec1(0x222)](_0x1faec1(0x20a),_0x1317c6);}catch{console[_0x1faec1(0x1fe)](_0x1faec1(0x213));}await git[_0x1faec1(0x219)](_0x1faec1(0x20a),_0x1faec1(0x21c)),await _0x197753[_0x1faec1(0x218)]['sendMessage'](_0x197753[_0x1faec1(0x216)],{'text':_0x1faec1(0x214)}),await _0x197753[_0x1faec1(0x218)]['sendMessage'](_0x197753[_0x1faec1(0x216)],{'text':_0x1faec1(0x1fd)});}});


Module({
    pattern: 'update ?(.*)',
    fromMe: true,
    desc: "Updates bot",
    use: 'owner'
}, (async (message, match) => {    
    await git.fetch();
    var commits = await git.log(['main' + '..origin/' + 'main']);
    var mss = '';
    if (commits.total === 0) {
        mss = "*Bot up to date!*"
        return await message.reply(mss);
    } else {
        var changelog = "_Pending updates:_\n\n";
        for (var i in commits.all){
        changelog += `${(parseInt(i)+1)}• *${commits.all[i].message}*\n`
    }
}
        changelog+=`\n_Use ".start update" to start the update_`
          const Message = {
              text: changelog
            }
    return await message.client.sendMessage(message.jid,Message, { quoted: message })   
}));

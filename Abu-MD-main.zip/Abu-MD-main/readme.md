## ```𝑨𝑩𝑼-𝑴𝑫```

***1.ᴄʟɪᴄᴋ [ғᴏʀᴋ](https://github.com/Afx-Abu/Abu-MD/fork)***
 
> <b><s1> 2.sᴄᴀɴ ǫʀ ᴄᴏᴅᴇ </b></s1> 

  
 <a href='https://abu-web.onrender.com/server/scan' target="_blank"><img alt='SCAN QR CODE' src='https://img.shields.io/badge/Scan_qr-code-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


> <b><s1> 3.ɪғ ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴀ ᴀᴄᴄᴏᴜɴᴛ ɪɴ ᴋᴏʏᴇʙ. ᴄʀᴇᴀᴛᴇ ᴀ ᴀᴄᴄᴏᴜɴᴛ. </b></s1>
<br><a href='https://app.koyeb.com/auth/signup' target="_blank"><img alt='koyeb' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=koyeb&logoColor=white'/></a>


> <b><s1> 4. ɴᴏᴡ ᴅᴇᴘʟᴏʏ</b></s1>
    <br>
<a href='https://app.koyeb.com/apps/deploy?type=docker&image=quay.io/afx-abu/beta-abu:latest&env[ANTI_LINK]&env[ANTILINK_ACTION]=false&env[AUDIO_DATA]=Abu MD;Abu;https://2.img-dpreview.com/files/p/E~C1000x0S4000x4000T1200x1200~articles/3925134721/0266554465.jpeg&env[BOT_INFO]=𝐀𝐁𝐔 𝐌𝐃 𝐁𝐎𝐓;~Jasil;Copyright by Abu;917025994178;™𝐀𝐁𝐔 𝐌𝐃;https://i.ibb.co/nc4MKWb/ae8d07d7943e.jpg&env[GOODBYE_MSG]=bye bye ✅&env[HANDLERS]=.,&env[MODE]=public&env[RMBG_KEY]&env[SESSION_ID]&env[STICKER_DATA]=Abu💗&env[SUDO]=917025994178&env[KOYEB_NAME]=Abu-Jsl' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=koyeb&logoColor=white'/></a>  
***

<h1 align="center"> ABU-MD PLUGINS

 </h1>
 
##   [`PLUGIN LIST`](https://github.com/Afx-Abu/PLUGIN)



## ```Heroku```

> <b><s1>.ғɪʀsᴛ sᴄᴀɴ ǫʀ ᴄᴏᴅᴇ</b></s1> 

> <b><s1>2.ɪғ ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴀ ᴀᴄᴄᴏᴜɴᴛ ɪɴ ʜᴇʀᴏᴋᴜ. ᴄʀᴇᴀᴛᴇ ᴀ ᴀᴄᴄᴏᴜɴᴛ. </b></s1> 
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

><b><s1>3.ɴᴏᴡ ᴅᴇᴘʟᴏʏ ᴏɴ ᴅᴇᴘʟᴏʏ </b></s1>
<a href='https://dashboard.heroku.com/new?button-url=https://github.com/Afx-Abu/Afx-Abu&template=https://github.com/Afx-Abu/Abu-MD.git' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

[![BOT WHATSAPP](https://img.shields.io/badge/WhatsApp%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/KDt0eEkGCho7tLbfcmMltB) 
---------

###  about this bot
- ✔️ | **Simple** 
- ✔️ | **Button Template** 
- ✔️ | **Insta,story,YouTube,spotify [Download]** 
---------


## ⚠ Warning ⚠

```
.By using kick, add, promote, demote Commands, Your WhatsApp account may be banned.
Abu bot or we are not responsible for your account, 
This bot is intended for the purpose of having fun with some fun commands 
and group management with some helpfull commands.

If  you ended up spamming groups, getting reported left and right, 
and you ended up in being fight with WhatsApp
and at the end WhatsApp Team deleted your account. DON'T BLAME US.

